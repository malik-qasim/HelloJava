/* This function marks the start of the farm */
int start_farm()
{
    return 1;
}

unsigned addval_402(unsigned x)
{
    return x + 2428995656U;
}

unsigned addval_323(unsigned x)
{
    return x + 2425393240U;
}

unsigned addval_396(unsigned x)
{
    return x + 2425379019U;
}

void setval_103(unsigned *p)
{
    *p = 2428995912U;
}

unsigned addval_313(unsigned x)
{
    return x + 3284634440U;
}

unsigned addval_190(unsigned x)
{
    return x + 1086492760U;
}

unsigned getval_447()
{
    return 3281031384U;
}

unsigned getval_241()
{
    return 3284633928U;
}

/* This function marks the middle of the farm */
int mid_farm()
{
    return 1;
}

/* Add two arguments */
long add_xy(long x, long y)
{
    return x+y;
}

unsigned getval_124()
{
    return 3524837769U;
}

void setval_154(unsigned *p)
{
    *p = 2429979960U;
}

unsigned getval_341()
{
    return 2447411528U;
}

unsigned addval_307(unsigned x)
{
    return x + 3674784201U;
}

unsigned getval_134()
{
    return 2429977062U;
}

unsigned getval_238()
{
    return 3372275337U;
}

void setval_428(unsigned *p)
{
    *p = 3268053258U;
}

unsigned getval_209()
{
    return 3531134601U;
}

void setval_330(unsigned *p)
{
    *p = 3380920745U;
}

void setval_474(unsigned *p)
{
    *p = 3525367305U;
}

void setval_160(unsigned *p)
{
    *p = 3281043849U;
}

unsigned getval_230()
{
    return 3380920777U;
}

unsigned getval_319()
{
    return 3232028297U;
}

void setval_130(unsigned *p)
{
    *p = 2430634312U;
}

void setval_128(unsigned *p)
{
    *p = 3281046153U;
}

unsigned addval_146(unsigned x)
{
    return x + 3222850185U;
}

unsigned addval_352(unsigned x)
{
    return x + 2430634312U;
}

unsigned addval_368(unsigned x)
{
    return x + 2425408009U;
}

void setval_229(unsigned *p)
{
    *p = 2429159890U;
}

void setval_121(unsigned *p)
{
    *p = 3281043853U;
}

unsigned getval_142()
{
    return 1740884617U;
}

unsigned addval_308(unsigned x)
{
    return x + 3374369419U;
}

unsigned addval_282(unsigned x)
{
    return x + 2430634344U;
}

unsigned addval_496(unsigned x)
{
    return x + 3286272320U;
}

unsigned addval_422(unsigned x)
{
    return x + 3286239560U;
}

void setval_294(unsigned *p)
{
    *p = 3252717896U;
}

unsigned addval_129(unsigned x)
{
    return x + 3230976649U;
}

unsigned getval_475()
{
    return 3372799625U;
}

unsigned addval_343(unsigned x)
{
    return x + 3523789193U;
}

unsigned addval_279(unsigned x)
{
    return x + 3224950409U;
}

void setval_377(unsigned *p)
{
    *p = 2497743176U;
}

void setval_477(unsigned *p)
{
    *p = 3229139337U;
}

/* This function marks the end of the farm */
int end_farm()
{
    return 1;
}
